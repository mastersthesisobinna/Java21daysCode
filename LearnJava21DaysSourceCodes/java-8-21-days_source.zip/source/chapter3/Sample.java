/* Solution to Chapter 3, Exercise 2 in Teach Yourself Java in 21 Days (Covering Java 8
   and Android by Rogers Cadenhead. */

package com.java21days;

class Sample {
    int height;
    int weight;
    int depth;
}

