package com.java21days;

import java.util.*;

public interface DmozHandler {
    public HashMap getRandomSite();
}
