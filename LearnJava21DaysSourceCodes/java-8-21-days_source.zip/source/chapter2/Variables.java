package com.java21days;

public class Variables {

    public static void main(String[] arguments) {
        final char UP = 'U';
        byte initialLevel = 12;
        short location = 13250;
        int score = 3500100;
        boolean newGame = true;

        System.out.println("Level: " + initialLevel);
        System.out.println("Up: " + UP);
    }
}
