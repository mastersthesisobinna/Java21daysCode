/* Solution to Chapter 1, Exercise 2 in Teach Yourself Java in 21 Days (Covering Java 8
   and Android by Rogers Cadenhead. */
   
class ChessPiece {
    String color;
    int startingPosition;
}
